<!-- 
    Document  : Page d'accueil du PA
    Modify on : 08 oct. 2018
    Author    : Louis
	Group 	  : Hubert, Thibault, Guillaume, Louis, Aurélien
-->
<?php
	session_start();
?>
<!DOCTYPE html>
<html>
	<head>
		<title>Chat Box</title>
		<meta charset="UTF-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel="stylesheet" href="style.css" />
	</head>
	<body>
		<?php include("bandeau_avatar.php")?>

		
		<!-- Menu compte -->
		<?php include("menu_compte.php");?>

		<!-- The flexible grid (content) -->
		<div id="conteneur_central">
			<?php include("menu_navigation.php");?>
			<div class="main">
				<section>
					<h1>Chat Box</h1>
						<?php 
							echo $_SESSION['message']."<br />";
							echo "<p>";
								echo "<form action='chat_box_post.php' method='post'>";
									if (isset($_SESSION['connexion']) && ($_SESSION['group'] == 4 || $_SESSION['group'] == 3))
									{
										echo "<label for='chat_box_moderation_id'>Supprimer le message <span class='small'>(id du message)</span>:</label><br />";
										echo "<input type='text' name ='chat_box_moderation_id' id='chat_box_moderation_id' /><br />";
										echo "<input type='submit' value='Supprimer' />";
									}
									echo "<label for='chat_box_message'>Message : </label><br /><textarea name='chat_box_message' id='chat_box_message' rows='5' cols='80'></textarea><br />";
									echo "<input type='submit' value='Envoyer' />";
								echo "</form>";
							echo "</p>";
							
						// Connexion à la base de données
						include("bdd_connexion.php");
						// Requête pour récupérer les 50 derniers messages
						$reponse = $bdd->query('SELECT id, login, message, message_heure FROM chat_box ORDER BY ID DESC LIMIT 0, 50');

						// Affichage des 50 dernier messages (les données sont protégées grâce à htmlspecialchars)
						while ($donnees = $reponse->fetch())
						{
							echo "<p>".htmlspecialchars($donnees['id'])." - ".htmlspecialchars($donnees['message_heure'])."@<strong>".htmlspecialchars($donnees['login'])."</strong> : ".htmlspecialchars($donnees['message'])."</p>";
						}
						$reponse->closeCursor();
					?>
				</section>
			</div>
			<!-- Block bannière -->
			<div class ="banniere">
				
			</div>
		</div>
		
		<!-- Footer -->
		<?php include("footer.php");?>
	</body>
</html>
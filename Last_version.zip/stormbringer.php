<!-- 
    Document  : Page d'accueil du PA
    Modify on : 08 oct. 2018
    Author    : Louis
	Group 	  : Hubert, Thibault, Guillaume, Louis, Aurélien
-->
<?php
	session_start();
?>
<!DOCTYPE html>
<html>
	<head>
		<title>Stormbringer</title>
		<meta charset="UTF-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel="stylesheet" href="style.css" />
	</head>
	<body>
		<?php include("bandeau_avatar.php")?>

		
		<!-- Menu compte -->
		<?php include("menu_compte.php");?>

		<!-- The flexible grid (content) -->
		<div id="conteneur_central">
			<?php include("menu_navigation.php");?>			
			<div class="presentation_jdr_conteneur_central">
				<h1 class="presentation_jdr_titre_page">Stormbringer</h1>
				<div class ="presentation_jdr_contenu">
					<p>Stormbringer, un nom qui évoque bien des souvenirs et une foule de sentiments contradictoires 
					pour tous celles et ceux qui ont lu le Cycle d’Elrik de Michael Moorcock. Synonyme de fatalité, 
					de combats épiques, de choix cornéliens et de voyages dans des mondes fantastiques, loin des canevas
					des	auteurs classiques du genre comme Howard ou Tolkien. Quoi de plus normal donc que cette série ait
					été	adaptée en jeu de rôle, pour le plus grand plaisir des fans. Néanmoins, comme nous le verrons dans
					ce Dice Roller, rester fidèle à une saga de romans aussi emblématique que celle de Moorcock ne va pas 
					sans aboutir à certains problèmes.</p>
				</div>
			</div>
		</div>
		
		<!-- Footer -->
		<?php include("footer.php");?>
	</body>
</html>
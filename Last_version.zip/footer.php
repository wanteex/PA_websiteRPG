<div class="footer">
  <a href="mention_legale.php" target="_blank">Information Mention Légale</a>
</div>
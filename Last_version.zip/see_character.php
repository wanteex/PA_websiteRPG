<!-- 
    Document  : Page d'accueil du PA
    Modify on : 08 oct. 2018
    Author    : Guillaume
	Group 	  : Hubert, Thibault, Guillaume, Louis, Aurélien
-->
<?php
	session_start();
?>
<!DOCTYPE html>
<html>
	<head>
		<title>Inscription</title>
		<meta charset="UTF-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel="stylesheet" href="style.css" />
	</head>
	<body>
		<?php include("bandeau_avatar.php")?>

		
		<!-- Menu compte -->
		<?php include("menu_compte.php");?>

		<!-- The flexible grid (content) -->
		<div id="conteneur_central">
			<?php include("menu_navigation.php");?>  
    <div class="main">
        <h2>Voir ses personnages</h2>
        <?php
                            include("includes/identifiants.php");
                            $reponse1 = $bdd->query('SELECT * FROM personnage WHERE id_joueur = '.$_SESSION['id']);
                        ?>
        <form method="post" action="see_character.php">

            <label for="perso">quel personnage voulez vous voir ?</label>
            <select name="perso" id="perso">
                <?php
                                    while ($donnees1 = $reponse1->fetch())
                                    {
                ?>
                                        <option value=<?php echo $donnees1['id'];?> >
                                            <?php echo $donnees1['nom']; ?>
                                        </option>
                <?php
                                    }
                        ?>
            </select>
            <p><input type="submit" value="Voir" /></p>
            <?php
            if (isset($_POST['perso'])) {
        
                                $reponseperso= $bdd->query('SELECT * FROM personnage Where id ='.$_POST['perso']);
                                $donnees = $reponseperso->fetch();
                                $reponsenatio = $bdd->query('SELECT * FROM nationality Where id_na ='.$donnees['id_nationalite']);
                                $donneesnatio = $reponsenatio->fetch();
                        
                        ?>
        
            
        <h3>Nom:</h3><p><?php echo $donnees['nom'] ;?></p>
        <div style="background-color:lightblue;">
            <div style="background-color:lightpink">
                <h3>SEXE</h3>
                <p><?php echo $donnees['sexe'] ;?></p>
            </div>
            <div style="background-color:lightgreen">
                <h3>AGE</h3>
                <p><?php echo $donnees['age'] ;?></p>
            </div>
            <div style="background-color:red">
                <h3>YEUX</h3>
                <p><?php echo $donnees['yeux'] ;?></p>
            </div>
            <div style="background-color:lightyellow">
                <h3>CHEVEUX</h3>
                <p><?php echo $donnees['cheveux'] ;?></p>
            </div>
            
            
            <div style="background-color:lightgreen">
                <h3>NATIONALITY</h3>
                <p><?php echo $donneesnatio['name'] ;?></p>
            </div>
            <div style="background-color:lightyellow">
                <h3>CLASSE SOCIALE</h3>
                <p>
                    <?php 
                                            if ($donnees['id_classe_social1'] != 1) {
                                                $reponseSC = $bdd->query('SELECT * FROM social_class Where id_SC ='.$donnees['id_classe_social1']);
                                                $donneesSC = $reponseSC->fetch();
                                                echo $donneesSC['name'].",";
                                            }
                                            if ($donnees['id_classe_social2'] != 1) {
                                                $reponseSC = $bdd->query('SELECT * FROM social_class Where id_SC ='.$donnees['id_classe_social2']);
                                                $donneesSC = $reponseSC->fetch();
                                                echo $donneesSC['name'].",";
                                            }
                                            if ($donnees['id_classe_social3'] != 1) {
                                                $reponseSC = $bdd->query('SELECT * FROM social_class Where id_SC ='.$donnees['id_classe_social3']);
                                                $donneesSC = $reponseSC->fetch();
                                                echo $donneesSC['name'];
                                            }
                                        ?>
                </p>
            </div>
            <div>
                <h3>CULTE</h3>
                <p>
                    <?php
                        $reponsecult = $bdd->query('SELECT * FROM cult Where id_cu ='.$donnees['id_culte']);
                        $donneescult = $reponsecult->fetch();
                        echo $donneescult['name_cult'] ;?>
                </p>
            </div>
        </div>
        <div style="background-color:lightgreen;">
            <div style="background-color:yellow;">
                <h3>CARACTERISTIQUE</h3>
                <p>
                    <?php echo 'FORce: '.$donnees['forc'] ;?>
                </p>
                <p>
                    <?php echo 'CONstitution: '.$donnees['constitution'] ;?>
                </p>
                <p>
                    <?php echo 'TAIlle: '.$donnees['taille'] ;?>
                </p>
                <p>
                    <?php echo 'INTelligence: '.$donnees['intelligence'] ;?>
                </p>
                <p>
                    <?php echo 'POUvoir: '.$donnees['pouvoir'] ;?>
                </p>
                <p>
                    <?php echo 'DEXterité: '.$donnees['dexterite'] ;?>
                </p>
                <p>
                    <?php echo 'CHArisme: '.$donnees['charisme'] ;?>
                </p>
            </div>
            <div>
                <h3>SANTE</h3>
                <p>
                    <?php echo 'Point de vie actuel: '.$donnees['pv'] ;?>
                </p>
                <p>
                    <?php echo 'Point de vie max: '.$donnees['pv_max'] ;?>
                </p>
            </div>
            <div>
                <h3>SANTE MENTAL</h3>
                <p>
                    <?php echo 'Sante mental actuel: '.$donnees['sante_mental'] ;?>
                </p>
                <p>
                    <?php echo 'Seuil de folie temporaire: '.$donnees['SFT'] ;?>
                </p>
            </div>
        
        </div>   
        <div style="background-color:grey;">
            <div style="background-color:grey;">
                <h3>CONNAISSANCE</h3>
                <p>
                    <?php echo 'Connaissance bonus:  '.$donnees['connaissance_bonus'] ;?>
                </p>
                <p>
                    <?php echo 'Evaluer un trésors: '.$donnees['evaluer_tresor'] ;?>
                </p>
                <p>
                    <?php echo 'Premier soin: '.$donnees['premier_soin'] ;?>
                </p>
                <p>
                    <?php echo 'Cartographie: '.$donnees['cartographie'] ;?>
                </p>
                <p>
                    <?php echo 'Mémoriser: '.$donnees['memoriser'] ;?>
                </p>
                <p>
                    <?php echo 'Connaissance des plantes: '.$donnees['connaissance_plantes'] ;?>
                </p>
                <p>
                    <?php echo 'Connaissance des poisons: '.$donnees['connaissance_poisons'] ;?>
                </p>
                </br>
                <p>
                    <?php echo 'Language Commun: '.$donnees['LLC'].'/'.$donnees['PLC'] ;?>
                </p>
                <p>
                    <?php echo 'Bas Melnibonéen: '.$donnees['LBM'].'/'.$donnees['PBM'] ;?>
                </p>
                <p>
                    <?php echo 'Haut Melnibonéen: '.$donnees['LHM'].'/'.$donnees['PHM'] ;?>
                </p>
                <p>
                    <?php echo 'Pande: '.$donnees['LP'].'/'.$donnees['PP'] ;?>
                </p>
                <p>
                    <?php echo 'Mabden: '.$donnees['LM'].'/'.$donnees['PM'] ;?>
                </p>
                <p>
                    <?php echo 'Orgien: '.$donnees['LO'].'/'.$donnees['PO'] ;?>
                </p>
            </div>   
            <div style="background-color:yellow;" >
                <h3>Compétence d'armes (attaque // dégats // parade)</h3>
                <?php
                    $weaponskill = explode(";", $donnees['Combat']);
                    $i =0;
                    $j =1;
                    $bob = "";
                    foreach ($weaponskill as $value ) {
                        if ($i == 0 && $value!="") {
                            $reponseatt = $bdd->query('SELECT * FROM weapon Where id ='.$value);
                            $donneesatt = $reponseatt->fetch();
                            $bob .="n° ".$j." ".$donneesatt['name']." :";
                            $j +=1;
                        }else{
                            $bob .= $value."  //  ";
                        }
                        
                        $i= $i +1;
                        if ($i>=4) {
                            echo "<p>".$bob."</p>";
                            $i =0;
                            $bob="";
                        }
                        
                        
                    }
               ?>
            </div>
            <div>
                <h3>Communication</h3>
                <p>
                    <?php echo 'Communication bonus:  '.$donnees['communication_bonus'] ;?>
                </p>
                <p>
                    <?php echo 'Crédit: '.$donnees['credit'] ;?>
                </p>
                <p>
                    <?php echo 'Eloquence: '.$donnees['eloquence'] ;?>
                </p>
                <p>
                    <?php echo 'Persuader: '.$donnees['persuader'] ;?>
                </p>
                <p>
                    <?php echo 'Chanter: '.$donnees['chanter'] ;?>
                </p>
            </div>
            <div>
                <h3>Manipulation</h3>
                <p>
                    <?php echo 'Manipulation bonus:  '.$donnees['manipulation_bonus'] ;?>
                </p>
                <p>
                    <?php echo 'Jongler: '.$donnees['jongler'] ;?>
                </p>
                <p>
                    <?php echo 'Crocheter: '.$donnees['crocheter'] ;?>
                </p>
                <p>
                    <?php echo 'Passe-Passe: '.$donnees['passe_passe'] ;?>
                </p>
                <p>
                    <?php echo 'Faire un piège: '.$donnees['faire_piege'] ;?>
                </p>
                <p>
                    <?php echo 'Faire un noeud: '.$donnees['faire_noeud'] ;?>
                </p>
            </div>
            
        </div>
        <div>
            <div>
                <h3>Perception</h3>
                <p>
                    <?php echo 'Perception bonus:  '.$donnees['perception_bonus'] ;?>
                </p>
                <p>
                    <?php echo 'Equilibre: '.$donnees['equilibre'] ;?>
                </p>
                <p>
                    <?php echo 'Ecouler: '.$donnees['ecouter'] ;?>
                </p>
                <p>
                    <?php echo 'Sentir: '.$donnees['sentir'] ;?>
                </p>
                <p>
                    <?php echo 'Chercher: '.$donnees['chercher'] ;?>
                </p>
                <p>
                    <?php echo 'Voir: '.$donnees['voir'] ;?>
                </p>
                <p>
                    <?php echo 'Goûter: '.$donnees['gouter'] ;?>
                </p>
                <p>
                    <?php echo 'Pister: '.$donnees['pister'] ;?>
                </p>
            
            </div>
            
            <div>
                <h3>Agility</h3>
                <p>
                    <?php echo 'Agilité bonus:  '.$donnees['agilite_bonus'] ;?>
                </p>
                <p>
                    <?php echo 'Grimper: '.$donnees['grimper'] ;?>
                </p>
                <p>
                    <?php echo 'Eviter: '.$donnees['eviter'] ;?>
                </p>
                <p>
                    <?php echo 'Sauter: '.$donnees['sauter'] ;?>
                </p>
                <p>
                    <?php echo 'Equitation: '.$donnees['equitation'] ;?>
                </p>
                <p>
                    <?php echo 'Nager: '.$donnees['nager'] ;?>
                </p>
                <p>
                    <?php echo 'Culbuter: '.$donnees['culbuter'] ;?>
                </p>
            </div>
            
            <div>
            <h3>Discretion</h3>
                <p>
                    <?php echo 'Discretion bonus:  '.$donnees['discretion_bonus'] ;?>
                </p>
                <p>
                    <?php echo 'Embuscade: '.$donnees['embuscade'] ;?>
                </p>
                <p>
                    <?php echo 'Dissimuler: '.$donnees['dissimuler'] ;?>
                </p>
                <p>
                    <?php echo 'Se cacher: '.$donnees['se_cacher'] ;?>
                </p>
                <p>
                    <?php echo 'Mouvement silencieux: '.$donnees['mouvement_silencieux'] ;?>
                </p>
                <p>
                    <?php echo 'Couper un bourse: '.$donnees['couper_bourse'] ;?>
                </p>
            </div>
        </div>

    </div><!-- Fin du div main-->

            <?php } ?>
			</div>
			<!-- Block bannière -->
			<div class ="banniere">
				
			</div>
		</div>
		
		<!-- Footer -->
		<?php include("footer.php");?>
	</body>
</html>

<div class="menu_compte">
	<?php
	    echo "<img src='images/logo_PA.svg' width=='200' height='200'/>";
		// Vérification que l'utilisateur est connecté pour afficher un lien vers la page compte et le bouton deconnexion
		if (isset($_SESSION['connexion']))
		{
			echo "<a href='compte.php'>".$_SESSION['login']."</a>";
			echo "<a href='deconnexion.php'>Déconnexion</a>";
		}
		// Sinon afficher les boutons inscription et connexion
		else
		{
			echo "<a href='inscription.php'>Inscription</a>";
			echo "<a href='connexion.php'>Connexion</a>";
		}
	?>
</div>
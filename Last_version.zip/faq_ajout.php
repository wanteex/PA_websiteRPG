<!-- 
    Document  : Page d'accueil du PA
    Modify on : 08 oct. 2018
    Author    : Louis
	Group 	  : Hubert, Thibault, Guillaume, Louis, Aurélien
-->
<?php
	session_start();
?>
<!DOCTYPE html>
<html>
	<head>
		<title>FAQ</title>
		<meta charset="UTF-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel="stylesheet" href="style.css" />
	</head>
	<body>
		<?php include("bandeau_avatar.php")?>

		
		<!-- Menu compte -->
		<?php include("menu_compte.php");?>

		<!-- The flexible grid (content) -->
		<div id="conteneur_central">
			<?php include("menu_navigation.php");?>
			<div class="main">
				<section>
					<?php
						// Vérification de la connexion, des droits admins et du contenu des champs
						if ($_SESSION['connexion'] && $_SESSION['group'] == 4 && $_POST['faq_question'] != "" && $_POST['faq_reponse'] != "")
						{
							// Connexion à la base de données
							include("bdd_connexion.php");	
							
							// Test pour ajouter une news
							if($_POST['faq_modif_id'] == "" && ($_POST['faq_question'] != "" || $_POST['faq_reponse'] != ""))
							{							
								// Requête préparée pour insérer un nouveau couple question / réponse
								$req = $bdd->prepare('INSERT INTO faq (question, reponse) VALUES(?, ?)');
								$req->execute(array($_POST['faq_question'], $_POST['faq_reponse']));
								$_SESSION['message']="";
							}
						
							// Requête préparée pour modifier une question / réponse
							if($_POST['faq_modif_id'] != "" && ($_POST['faq_question'] != "" || $_POST['faq_reponse'] != ""))
							{
								// Test si le champ question est rempli
								if($_POST['faq_question'] != "")
								{
									$req = $bdd->prepare('UPDATE faq SET question = :question WHERE id = :id');
											$req->execute(array(
												'question' => $_POST['faq_question'],
												'id' => $_POST['faq_modif_id']
												));
								}
								// Test si le champ reponse est rempli
								if($_POST['faq_reponse'] != "")
								{
									$req = $bdd->prepare('UPDATE faq SET reponse = :reponse WHERE id = :id');
											$req->execute(array(
												'reponse' => $_POST['faq_reponse'],
												'id' => $_POST['faq_modif_id']
												));
								}
							}
						}
						else
						{
							$_SESSION['message'] = "Erreure.";
						}
						header('Location: faq.php');
						exit();
			?>
				</section>
			</div>
			<!-- Block bannière -->
			<div class ="banniere">
				
			</div>
		</div>
		
		<!-- Footer -->
		<?php include("footer.php");?>
	</body>
</html>
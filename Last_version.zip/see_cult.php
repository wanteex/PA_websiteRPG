<!-- 
    Document  : Page d'accueil du PA
    Modify on : 08 oct. 2018
    Author    : Guillaume
	Group 	  : Hubert, Thibault, Guillaume, Louis, Aurélien
-->
<?php
	session_start();
?>
<!DOCTYPE html>
<html>
	<head>
		<title>Inscription</title>
		<meta charset="UTF-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel="stylesheet" href="style.css" />
	</head>
	<body>
		<?php include("bandeau_avatar.php")?>

		
		<!-- Menu compte -->
		<?php include("menu_compte.php");?>

		<!-- The flexible grid (content) -->
		<div id="conteneur_central">
			<?php include("menu_navigation.php");?>
                    <div class="main">

                            <article id="Allarticle">
                                <header>
                                    <h2>Les Cultes</h2>
                                </header>
                                <p>Le culte de votre personnage va influencer sur la façons de penser et d'agir de celui-ci.</br></p>
                            </article>
                            <table>
        <tr>
            <td>Nom</td>
            <td>type de divinité</td>
            <td>devoir envers le dieux</td>    
        </tr>
                                <?php
                                    $reponse = $bdd->query('SELECT * FROM cult Where id_cu >=1');
                                    while ($donnees = $reponse->fetch())
                                     {
                                ?>
                                        <tr>
                                            <td><?php echo $donnees['name_cult'];?></td>
                                            <td><?php echo $donnees['type_god']?></td>
                                            <td><?php echo $donnees['duty']; ?></td>
                                        </tr>
                                       
                                <?php
                                    }
                                ?>
        </table>
                   </div>
			<!-- Block bannière -->
			<div class ="banniere">
				
			</div>
		</div>
		
		<!-- Footer -->
		<?php include("footer.php");?>
	</body>
</html>
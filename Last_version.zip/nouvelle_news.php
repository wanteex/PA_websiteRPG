﻿<!-- 
    Document  : Page d'accueil du PA
    Modify on : 08 oct. 2018
    Author    : Louis
	Group 	  : Hubert, Thibault, Guillaume, Louis, Aurélien
-->
<?php
	session_start();
?>
<!DOCTYPE html>
<html>
	<head>
		<title>Création news</title>
		<meta charset="UTF-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel="stylesheet" href="style.css" />
	</head>
	<body>
		<?php include("bandeau_avatar.php")?>

		
		<!-- Menu compte -->
		<?php include("menu_compte.php");?>

		<!-- The flexible grid (content) -->
		<div id="conteneur_central">
			<?php include("menu_navigation.php");?>
			<div class="main">
				<section>
					<h1>Nouvelle/Modification news</h1>
					<?php 
						echo "<form method='post' action='creation_news.php'>";
							echo "<p>";
								echo "<label for='news_update'>Modification d'une news existante<span class='small'>(saisir l'ID de la news.)</span></label>";
								echo "<input type='checkbox' name='news_update' id='news_update' value='true' /><br>";
								echo "<label for='news_id'>ID de la news :</label><br /><textarea name='news_id' id='news_id' rows='1' cols='40'></textarea><br />";
								echo "<label for='news_source'>Source de la news :</label><br />";
								echo "<textarea name='news_source' id='news_source' rows='2' cols='80'></textarea><br />";
								echo "<label for='news_title'>Titre de la news :</label><br />";
								echo "<textarea name='news_title' id='news_title' rows='2' cols='80'></textarea><br />";
								echo "<label for='news_content'>Contenue de la news :</label><br />";
								echo "<textarea name='news_content' id='news_content' rows='40' cols='80'></textarea><br />";
								
								echo "<input type='submit' value='Envoyer' />";
							echo "</p>";
						echo "</form>";
					?>
				</section>
			</div>
			<!-- Block bannière -->
			<div class ="banniere">
				
			</div>
		</div>
		
		<!-- Footer -->
		<?php include("footer.php");?>
	</body>
</html>
﻿<!-- 
    Document  : Page d'accueil du PA
    Modify on : 08 oct. 2018
    Author    : Louis
	Group 	  : Hubert, Thibault, Guillaume, Louis, Aurélien
-->
<?php
	session_start();
?>
<!DOCTYPE html>
<html>
	<head>
		<title>Création news</title>
		<meta charset="UTF-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel="stylesheet" href="style.css" />
	</head>
	<body>
		<?php include("bandeau_avatar.php")?>

		
		<!-- Menu compte -->
		<?php include("menu_compte.php");?>

		<!-- The flexible grid (content) -->
		<div id="conteneur_central">
			<?php include("menu_navigation.php");?>
			<div class="main">
				<section>
					<h1>Aperçu news</h1>
					<?php
						//Vérification d'envoie de formulaire avec tous les paramètres remplis
						if($_POST['news_title'] != "" && $_POST['news_content'])
						{
							$modif_champs = false;
							$modif_titre = false;
							// Connexion à la base de donnée
							include("bdd_connexion.php");
							// Modification d'une news
							//Vérification si la check box est coché et que l'id de la news est rempli
							if(isset($_POST['news_update']) && isset($_POST['news_id']))
							{
								$modification_date =date("Y-m-d");
								//Requête pour modifier le titre et le contenu de la news
								$req = "UPDATE news SET title = '".$_POST['news_title']."', content = '".$_POST['news_content']."', lien_source = '".$_POST['news_source']."', modification_date = '".$modification_date."' WHERE id = '".$_POST['news_id']."'";
								$bdd->exec($req);
								
								// Requête pour récupérer les informations de la news
								$reponse = $bdd->query("SELECT id, title, content, lien_source, creation_date, modification_date FROM news WHERE title = '".$_POST['news_title']."'");
								// Affichage des 3 dernière news (les données sont protégées grâce à htmlspecialchars)
								while ($donnees = $reponse->fetch())
								{
									echo "<div class='block_news'>";
									echo "<h3>".htmlspecialchars($donnees['title'])."</h3>";
									echo "<p>".htmlspecialchars($donnees['content'])."</p>";
									if($donnees['lien_source'] != "")
									{
										echo "<strong>Date de création : </strong>".htmlspecialchars($donnees['creation_date'])." /<strong> Dernière modification : </strong>".htmlspecialchars($donnees['modification_date'])." /<strong> ID : </strong>".htmlspecialchars($donnees['id'])." / <a href='".htmlspecialchars($donnees['lien_source'])."'>Source</a><br />";
									}
									else
									{
										echo "<strong>Date de création : </strong>".htmlspecialchars($donnees['creation_date'])." /<strong> Dernière modification : </strong>".htmlspecialchars($donnees['modification_date'])." /<strong> ID : </strong>".htmlspecialchars($donnees['id'])."<br />";
									}
									echo "</div>";
								}
							}
							// Création d'une news
							else
							{
								// Requête pour vérifier que le titre de la news n'est pas déjà utilisé
								$reponse = $bdd->query('SELECT title FROM news  WHERE title="'.$_POST['news_title'].'"');
								$titleverif = $reponse->fetch();
								// Vérification que le titre de la news n'est pas déjà utilisé
								if ($_POST['news_title'] != $titleverif['title'])
								{
									$creation_date =date("Y-m-d");
									$modification_date =date("Y-m-d");
									//Requête pour ajouter la news
									$reponse = $bdd->prepare('INSERT INTO news(title, content, lien_source, creation_date, modification_date) VALUES(:title, :content, :lien_source,:creation_date, :modification_date)');
									$reponse->execute(array(
										'title' => htmlspecialchars($_POST['news_title']),
										'content' => htmlspecialchars($_POST['news_content']),
										'lien_source' => htmlspecialchars($_POST['news_source']),
										'creation_date' => $creation_date,
										'modification_date' => $modification_date
									));
									// Requête pour récupérer les informations de la news
									$reponse = $bdd->query("SELECT id, title, content, lien_source, creation_date, modification_date FROM news WHERE title = '".$_POST['news_title']."'");
									$donnees = $reponse->fetch();
									
									echo "<div class='block_news'>";
									echo "<h3>".htmlspecialchars($donnees['title'])."</h3>";
									echo "<p>".htmlspecialchars($donnees['content'])."</p>";
									if($donnees['lien_source'] != "")
									{
										echo "<strong>Date de création : </strong>".htmlspecialchars($donnees['creation_date'])." /<strong> Dernière modification : </strong>".htmlspecialchars($donnees['modification_date'])." /<strong> ID : </strong>".htmlspecialchars($donnees['id'])." / <a href='".htmlspecialchars($donnees['lien_source'])."'>Source</a><br />";
									}
									else
									{
										echo "<strong>Date de création : </strong>".htmlspecialchars($donnees['creation_date'])." /<strong> Dernière modification : </strong>".htmlspecialchars($donnees['modification_date'])." /<strong> ID : </strong>".htmlspecialchars($donnees['id'])."<br />";
									}
									echo "</div>";;
									}
								//Génération du message d'erreur : titre news existant
								else
								{
									echo 'Titre de news existant.';
								}
							}
						}
						//Génération du message d'erreur : champs vide
						else
						{
							echo'Les champs titre et contenu doivent être remplis.';
						}
					?>
				</section>
			</div>
			<!-- Block bannière -->
			<div class ="banniere">
				
			</div>
		</div>
		
		<!-- Footer -->
		<?php include("footer.php");?>
	</body>
</html>
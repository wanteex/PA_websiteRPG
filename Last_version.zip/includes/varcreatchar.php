﻿<?php 
// Connexion à la base de données
if (isset($_SESSION['l1'])) {
	$_SESSION['l1']=0;
	$_SESSION['l2']=0;
	$_SESSION['l3']=0;
	$_SESSION['l4']=0;
	$_SESSION['l5']=0;
	$_SESSION['l6']=0;
	$_SESSION['l7']=0;
	$_SESSION['l8']=0;
}
?>

		<div id="logo_header">
			<div class="fakeimg" alt="Iamge 1">Image 1</div>
			<div class="fakeimg" alt="Iamge 2">Image 2</div>
			<div class="fakeimg" alt="Iamge 3">Image 4</div>
			<div class="fakeimg" alt="Iamge 4">Image 4</div>
			<div class="fakeimg" alt="Iamge 5">Image 5</div>
			<div class="fakeimg" alt="Iamge 6">Image 6</div>
			<div class="fakeimg" alt="Iamge 7">Image 7</div>
			<div class="fakeimg" alt="Iamge 8">Image 8</div>
			<div class="fakeimg" alt="Iamge 9">Image 9</div>
		</div>
		<!-- Header -->
		<div class="header">
		  <h1>Jeux de Rôles</h1>
		</div>
		
		<!-- Menu compte -->
		<div class="menu_compte">
			<?php						
				if (isset($_SESSION['id']) && isset($_SESSION['login']))
				{
					echo "<a href='http://projetapplicatif/deconnexion.php'>Déconnexion</a>";
				}
				else
				{
					echo "<a href='http://projetapplicatif/inscription.php'>Inscription</a>";
					echo "<a href='http://projetapplicatif/connexion.php'>Connexion</a>";
				}
			?>
		</div>

		<!-- The flexible grid (content) -->
		<div id="conteneur_central">
			<div class="menu_page">
				<nav>
					<ul>
						<li><a href="http://projetapplicatif/index.php">Accueil</a></li>
						<?php						
							if (isset($_SESSION['connexion']))
							{
								echo "<li><a href='compte.php'>Mon Compte</a></li>";
							}
						?>
						<li><a href="news.php">News</a></li>
						<?php						
							if (isset($_SESSION['connexion']) && $_SESSION['group'] == 4)
							{
								echo "<li><a href='nouvelle_news.php'>Nouvelle news</a></li>";
							}
						?>
						<li><a href="http://projetapplicatif/testhubert/calendrier.php">Planning</a></li>
						<li><a href="forum.php">Forum</a></li>
						<li><a href="faq.php">FAQ</a></li>
						<li><a href="contact.php">Contact</a></li>
					</ul>
					<ul>
                        <li><a href="stormbringer.php">Stormbringer</a></li>
                        <li><a href='http://projetapplicatif/Storm/see_nationality.php'>Nationalités</a></li>
                        <li><a href='http://projetapplicatif/Storm/see_class.php'>Classes sociales</a></li>
                        <li><a href='http://projetapplicatif/Storm/achat_storm.php'>Tables des achats</a></li>
                        <li><a href='http://projetapplicatif/Storm/see_cult.php'>Cultes</a></li>
						<?php						
							if (isset($_SESSION['id']) && isset($_SESSION['login']))
							{
								echo "<li><a href='http://projetapplicatif/Storm/character_creation.php'>Créer un personnage</a></li>
								<li><a href='http://projetapplicatif/Storm/see_character.php'>Voir ses personnages</a></li>
				                <li><a href='http://projetapplicatif/Storm/character_registration.php'>Enregistrer un personnages</a></li>";
							}
						?>						
					</ul>
				</nav>
			</div>
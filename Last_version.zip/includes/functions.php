<?php
function erreur($err='')
{
   $mess=($err!='')? $err:'Une erreur inconnue s\'est produite';
   exit('<p>'.$mess.'</p>
   <p>Cliquez <a href="./index.php">ici</a> pour revenir à la page d\'accueil</p></div></body></html>');
}
function SetNationality($number){
	switch ($number) {
    	case 1:
    	case 2:
    	    echo 'Melniboné';
    		break;
    	case 3:
    	case 4: 
    	case 5:
    		echo 'Pan_Tang';
    		break;
    	case 6: 
    	case 7: 
    	case 8: 
    		echo 'Myrrhyn';
    		break;
    	case 9: 
		case 10: 
    	case 11: 
    	case 12: 
    		echo 'Dharijor';
    		break;
    	case 13: 
    	case 14: 
    	case 15: 
    	case 16:
    		echo 'Jharkor';
    		break; 
    	case 17: 
    	case 18: 
    	case 19: 
    	case 20: 
    	case 21: 
    	case 22: 
    	case 23: 
    	case 24:
    		echo 'Shazaar';
    		break; 
    	case 25: 
    	case 26: 
    	case 27: 
    	case 28: 
    	case 29: 
    		echo 'Tarkesh';
    		break;
    	case 30: 
    	case 31: 
    	case 32: 
    	case 33: 
    	case 34: 
    	case 35: 
		case 36: 
    	case 37: 
    		echo 'Vilmir';
    		break;
    	case 38: 
    	case 39: 
    	case 40: 
    	case 41: 
    	case 42: 
    	case 43: 
    	case 44:
    		echo 'Ilmiora';
    		break; 
    	case 45: 
    	case 46: 
    	case 47: 
    	case 48: 
    	case 49: 
    		echo 'Nadsokor';
    		break;
    	case 50: 
    	case 51: 
    	case 52: 
    	case 53: 
    	case 54: 
    	case 55: 
    	case 56:
    		echo 'Désert_de_Larmes';
    		break; 
    	case 57: 
    	case 58: 
    	case 59: 
    	case 60: 
    		echo 'Eshmir';
    		break;
    	case 61: 
		case 62: 
    	case 63: 
    	case 64: 
    	case 65: 
    	case 66: 
    	case 67: 
    		echo 'Ile_des_Cités_Pourpres';
    		break;
    	case 68: 
    	case 69: 
    	case 70: 
    	case 71: 
    	case 72: 
    	case 73: 
    	case 74:
    		echo 'Argimiliar';
    		break; 
    	case 75: 
    	case 76: 
    	case 77: 
    	case 78: 
    	case 79: 
    	case 80: 
    	case 81:
    		echo 'Pikarayd';
    		break;
    	case 82: 
		case 83: 
    	case 84: 
    	case 85: 
    	case 86: 
    	case 87: 
    	case 88:
    		echo 'Lormyr';
    		break; 
    	case 89: 
    	case 90: 
    	case 91: 
    	case 92: 
    	case 93: 
    	case 94: 
    	case 95: 
    		echo 'Filkhar';
    		break;
    	case 96: 
    	case 97: 
    		echo 'Oin';
    		break;
    	case 98: 
    	case 99: 
    		echo 'Yu';
    		break;
    	case 100: 
    		echo 'Org';
    		break;
	}
}

function SetBonusDamageM($number){
	switch ($number) {
		case 1:
    	case 2:
    	case 3:
    	case 4: 
    	case 5:
    	case 6: 
    	case 7: 
    	case 8: 
    	case 9: 
		case 10: 
    	case 11: 
    	case 12: 
    	case 13: 
    	case 14: 
    	case 15: 
    	case 16:
            return '-1D6';
           // define('bodaM', '-1D6');
    		break;
    	case 17: 
    	case 18: 
    	case 19: 
    	case 20: 
    	case 21: 
    	case 22: 
    	case 23: 
    	case 24:
            return 'aucun bonus';
            //define('bodaM', 'aucun bonus');
    		break;
    	case 25: 
    	case 26: 
    	case 27: 
    	case 28: 
    	case 29: 
    	case 30: 
    	case 31: 
    	case 32: 
    	case 33: 
    	case 34: 
    	case 35: 
		case 36: 
    	case 37: 
    	case 38: 
    	case 39: 
    	case 40: 
            return '+1D6';
            //define('bodaM', '+1D6');
    		break;
    	case 41: 
    	case 42: 
    	case 43: 
    	case 44:
    	case 45: 
    	case 46: 
    	case 47: 
    	case 48: 
    	case 49: 
    	case 50:
            return '+2D6';
            //define('bodaM', '+2D6');
    		break;
	}
}
function SetBonusDamageT($number){
	switch ($number) {
		case 1:
    	case 2:
    	case 3:
    	case 4: 
    	case 5:
    	case 6: 
    	case 7: 
    	case 8: 
    	case 9: 
		case 10: 
    	case 11: 
    	case 12: 
    	case 13: 
    	case 14: 
    	case 15: 
    	case 16:
    		return '-1D4';
    		break;
    	case 17: 
    	case 18: 
    	case 19: 
    	case 20: 
    	case 21: 
    	case 22: 
    	case 23: 
    	case 24:
    		return 'aucun bonus';
    		break;
    	case 25: 
    	case 26: 
    	case 27: 
    	case 28: 
    	case 29: 
    	case 30: 
    	case 31: 
    	case 32: 
    	case 33: 
    	case 34: 
    	case 35: 
		case 36: 
    	case 37: 
    	case 38: 
    	case 39: 
    	case 40: 
    		return '+1D4';
    		break;
    	case 41: 
    	case 42: 
    	case 43: 
    	case 44:
    	case 45: 
    	case 46: 
    	case 47: 
    	case 48: 
    	case 49: 
    	case 50:
    		return '+2D4';
    		break;
	}
}
function SetAFLI($number){
    
	switch ($number) {
		case 1:
		return 'Cataracte, à moitié aveugle';
    		break;
    	case 2:
    	return 'Une oreille en moins, la compétence Ecouter est divisée par deux';
    		break;
    	case 3:
    	return 'Muet ou la langue tranchée';
    		break;
    	case 4: 
    	return 'Un oeil en moins';
    		break;
    	case 5:
    	return 'Plus de nez';
    		break;
    	case 6: 
    	return 'Dents totalement pourries, mauvaise haleine';
    		break;
    	case 7: 
    	return 'Plaies ouvertes';
    		break;
    	case 8: 
    	return 'Lépreux';
    		break;
    	case 9: 
    	return 'Hémophile';
    		break;
		case 10: 
		return 'Scorbuteux';
    		break;
    	case 11: 
    	$z = rand(1,4);
    	return $z.'doigts en moins';
    		break;
    	case 12: 
    	return 'Amputé d\'une main';
    		break;
    	case 13: 
    	return 'Amputé d\'un pied';
    		break;
    	case 14: 
    	return 'Amputé d\'un bras';
    		break;
    	case 15: 
    	return 'Amputé d\'une jambe';
    		break;
    	case 16:
    	return 'Amputé d\'un et bras et d\'une jambe';
    		break;
    	case 17: 
    	return 'Chauve et galeux';
    		break;
    	case 18: 
    	return 'Obèse';
    		break;
    	case 19: 
    	return 'Squelette vivant (maigre au dernier degré)';
    		break;
    	case 20: 
    	return 'Attardé mental (ôtez 1D4 points à l\'INT)';
    		break;
	}
}
function SetClass($number){
    switch ($number) {
        case 1:
        case 2:
        case 3:
        case 4: 
        case 5:
        case 6: 
        case 7: 
        case 8: 
        case 9: 
        case 10: 
        case 11: 
        case 12: 
        case 13: 
        case 14: 
        case 15: 
        case 16;
        case 17: 
        case 18: 
        case 19: 
        case 20: 
            return 'Guerrier';
            break;
        case 21: 
        case 22: 
        case 23: 
        case 24:
        case 25: 
        case 26: 
        case 27: 
        case 28: 
        case 29: 
        case 30:
            $test =rand(1,10);
            switch ($test) {
                case 1:
                case 2:
                case 3:
                case 4: 
                case 5:
                case 6: 
                case 7: 
                    return 'Marchand';
                    break;
                case 8: 
                case 9: 
                case 10: 
                    return 'Négociant';
                    break;
            }
            break; 
        case 31: 
        case 32: 
        case 33: 
        case 34: 
        case 35: 
        case 36: 
        case 37: 
        case 38: 
        case 39: 
        case 40: 
        case 41: 
        case 42: 
        case 43: 
        case 44:
        case 45:
            $test =rand(1,10);
            switch ($test) {
                case 1:
                case 2:
                case 3:
                case 4: 
                case 5:
                case 6: 
                case 7: 
                case 8: 
                    return 'Marin';
                    break;
                case 9: 
                    return 'Second';
                    break;
                case 10: 
                    return 'Capitaine';
                    break;
            }

            break; 
        case 46: 
        case 47: 
        case 48: 
        case 49: 
        case 50:
        case 51: 
        case 52: 
        case 53: 
        case 54: 
        case 55: 
        case 56:
        case 57: 
        case 58: 
        case 59: 
        case 60: 
            return 'Chasseur';
            break;
        case 61: 
        case 62: 
        case 63: 
        case 64: 
        case 65: 
            return 'Fermier';
            break;
        case 66: 
        case 67: 
        case 68: 
        case 69: 
        case 70: 
            return 'Prêtre';
            break;
        case 71: 
        case 72: 
        case 73: 
        case 74: 
        case 75: 
            return 'Noble';
            break;
        case 76: 
        case 77: 
        case 78: 
        case 79: 
        case 80: 
        case 81:
        case 82: 
        case 83: 
        case 84: 
        case 85: 
            return 'Voleur';
            break;
        case 86: 
        case 87: 
        case 88: 
        case 89: 
        case 90: 
            return 'Mendiant';
            break;
        case 91: 
        case 92: 
        case 93: 
        case 94: 
        case 95: 
        case 96: 
        case 97: 
        case 98: 
        case 99: 
        case 100: 
            return 'Artisan';
            break;
    }
}

function SetHistoirePerso($number){
switch ($number) {
        case 1:
            return 'Sixième sens, le personnage n\'est jamais surpris en combat. En cas d\'embuscade, le joueur a droit à un jet sous 3*POU pour la detecter.';
            break;
        case 2:
            return 'Possède 3 fioles de guérison de tpe 6 (tab 4.8.9.1)';
            break;
        case 3:
            return 'Possède une arme particulièrement bien forgée, ce qui lui octroie un bonus de +2 aux dommages.';
            break;
        case 4: 
            return 'Immunisé naturellement à 3 types de venin de serpent à choisir.';
            break;
        case 5:
            return 'A des dons d\'imitateur lui permettant de se fondre dans tous les milieux sociaux et culturels.';
            break;
        case 6: 
            return 'Champ de vision plus large, il voit parfaitement sur les côtés, +10% en Voir et en Pister.';
            break;
        case 7: 
            return 'Ouïe très developpée, +10% en écouter.';
            break;
        case 8: 
            return 'Ambidextre, manie les armes d\'une main comme de l\'autre avec les mêmes pourcentages.';
            break;
        case 9: 
            return 'Don naturel d\'amitié avec les animaux sauvages, ceux-ci, a moins d\'y être forcés, ne l\'attaquerons pas.';
            break;
        case 10: 
            return 'Possède un cheval de monte, +25% en Equitation.';
            break;
        case 11: 
            return 'A un ami influent, à determiner avec le maître du jeu.';
            break;
        case 12: 
            return 'Possède une ancienne carte indiquant l\'emplacement d\'un trésor. Son autenticité est laissée aà l\'appréciation du maître du jeu';
            break;
        case 13: 
        case 14: 
            return 'Bénéficie d\'une expérience particulière. Choisir une compétence et augmenter sa valeur de 1D10.';
            break;
        case 15: 
        case 16;
            return 'A participé à une grande bataille et a été décoré pour sa bravoure';
            break;
        case 17: 
        case 18: 
            return 'Possède un mystérieux tatouage sur l\'épaule';
            break;
        case 19: 
        case 20: 
            return 'Buveur impénitent, il connaît toutes les bonnes tavernes de la région';
            break;
        case 21: 
        case 22: 
        case 23: 
            return 'Possède un grimoir incompréhensible';
            break;
        case 24:
            return 'Croit fermement que le cataclysme inal est proche';
            break;
        case 25: 
        case 26: 
        case 27: 
        case 28: 
            return 'Possede une flûte "magique" mais ne sait pas s\'en servir';
            break;
        case 29: 
        case 30:
        case 31: 
            return 'Possède au doift un anneau de famille se léguant de génération en génération';
            break;
        case 32: 
        case 33: 
            return 'A recu en legs l\'arme de son père, à laquelle il tient plus qu\'à la vie';
            break;
        case 34: 
        case 35: 
        case 36: 
            return 'Collectionne les épées originales, et est prêt a toutes les folies pour les posséder';
            break;
        case 37: 
        case 38: 
        case 39: 
        case 40: 
            return 'File l\'amour parfait avec la fille du noble le plus proche. Mais avant d\'accorder la main de sa fille, le père exige de l\'aventurier qu\'il fasse les preuves de sa valeur';
            break;
        case 41: 
        case 42: 
        case 43: 
        case 44:
            return 'A la recherche d\'un frère jumeau disparu';
            break;
        case 45:
            return 'Coureur de jupon à toute épreuve, il laisse un héritier dans chaque ville qu\'il traverse, et autant de mères à ses trousses';
            break;
        case 46: 
        case 47: 
        case 48: 
        case 49: 
        case 50:
        case 51: 
            return 'Méticuleux au dernier degré, surtout en aventure';
            break;
        case 52: 
        case 53: 
            return 'Croit qu\'il est le fils abandonné d\'un roi et veut retrouver ses droits';
            break;
        case 54:
            return 'Possède une recette infaillible contre les piqûres de moustiques';
            break; 
        case 55: 
        case 56:
        case 57: 
        case 58: 
            return 'A goûté un fruit rare à la saveur exceptionnelle. Il cherche par tous les moyens à le retrouver pour le commercialiser';
            break;
        case 59: 
        case 60: 
        case 61: 
            return 'A la recherche de sa famille en esclavage';
            break;
        case 62: 
        case 63: 
        case 64: 
            return 'Particulièrement douillet, a besoin d\'un maximum de confort surtout en aventure';
            break;
        case 65: 
        case 66: 
            return 'Fier a l\'excès, ne supporte pas les irrespectueux';
            break;
        case 67: 
        case 68: 
            return 'Ignore le mensonge et la fourberie. De plus les mots embuscade, attaques par derrière, etc..., ne font pas partie de son vocabulaire';
            break;
        case 69: 
        case 70: 
            return 'Part en aventure pour retrouver la femme de ses rêves. Il l\'a apercue une nuit, au détour d\'une allée, dans une chaise à porteur aux rideaux à demi-tirés.';
            break;
        case 71: 
        case 72: 
            return 'Parieur invétéré, les défis les plus étranges ne lui font pas peur. Il attend avec impatience qu\'on lui demande d\'aller chercher la couronne d\'un roi en moins d\'un an';
            break;
        case 73: 
        case 74: 
        case 75: 
        case 76:
            return 'Seul le royaume des airs est interdit à l\'homme. Or notre personnage veut apprendre à voler a tout prix';
            break; 
        case 77: 
            return 'Veut retrouver l\'assassin de son meilleur ami, il remuera ciel et terre à travers tous les Jeunes Royaumes pour cela';
            break;
        case 78: 
        case 79: 
        case 80: 
        case 81:
            return 'Fait un rêve persistant qui doit bien avoir une signification ( à discretion du maître du jeu)';
            break;
        case 82: 
        case 83: 
            return 'Ne sait pas garder un sous en poches, qu\'il a d\'ailleurs percées';
            break;
        case 84: 
        case 85: 
        case 86: 
        case 87: 
        case 88: 
        case 89: 
        case 90: 
            return 'Accusé à tord de meurtre dans son pays, il cherche à prouver son innocence';
            break;
        case 91: 
            return 'Mysogine';
            break;
        case 92: 
            return 'A failli se noyer étant petit, il a une peur panique de l\'eau';
            break;
        case 93: 
            return 'A provoqué le parte d\'un objet important ( au choix du maître), il est poursuivi par les envoyé acharnés de son créancier';
            break;
        case 94: 
            return 'Allergie dramatique. Perd 50% de toutes ses compétences au contact de l\'allergène ( poils,pollen, etc...)';
            break;
        case 95: 
            return 'Amnésique, il ne connaît pas sa véritable identité, même s\'il conserve toutes ses compétences';
            break;
        case 96:   
            return 'Fait partie d\'une secte, il veut à tout prix la quitter en dépit des menaces de mort qui en découleraient';
            break;
        case 97: 
            return 'Fasciné par toutes les expériences et tentatives nouvelles, le personnage seras de tous les projets les plus fous. Jusqu\'à aujourd\'hui il a eu beaucoup de chance';
            break;
        case 98: 
            return 'A gravement manqué de respect à un noble de Pan Tang, ce dernier a juré de le faire entrer vivant dans un flacon';
            break;
        case 99: 
            return 'Estime que tout en ce monde n\'est qu\'illusion... même la mort. Qui sait si cette philosophie ne poussera pas le personnage à certains actes ? .....';
            break;
        case 100: 
            return 'A eu le malheur un jour d\'arbitrer un conflit entre un prêtre de la Loi. Les deux cultes sont à sa poursuite';
            break;
    }
}


?>

﻿<!-- 
    Document  : Page d'accueil du PA
    Modify on : 08 oct. 2018
    Author    : Louis
	Group 	  : Hubert, Thibault, Guillaume, Louis, Aurélien
-->
<?php
	session_start();
?>
<!DOCTYPE html>
<html>
	<head>
		<title>Connexion</title>
		<meta charset="UTF-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel="stylesheet" href="style.css" />
	</head>
	<body>
		<?php include("bandeau_avatar.php")?>

		
		<!-- Menu compte -->
		<?php include("menu_compte.php");?>

		<!-- The flexible grid (content) -->
		<div id="conteneur_central">
			<?php include("menu_navigation.php");?>
			<div class="main">
				<section>
					<h1>Connexion</h1>
					<?php
						// connexion a la bdd
						include("bdd_connexion.php");
						// Vérification que les deux champs sont remplis
						if($_POST['login'] != "" && $_POST['password'] != "")
						{	
							//  Récupération de l'utilisateur et de son pass hashé
							$reponse = $bdd->prepare('SELECT id, login, id_group, email, signup_date, password FROM users WHERE login = "'.$_POST['login'].'"');
							$reponse->execute(array(
								'login' => $_POST['login']));
							$resultat = $reponse->fetch();

							// Comparaison du pass envoyé via le formulaire avec la base
							$isPasswordCorrect = password_verify($_POST['password'], $resultat['password']);

							if (!$resultat)
							{
								$message = 'Mauvais identifiant ou mot de passe !';
								$form = true;
							}
							else
							{
								// Test si le combo login + mot de passe est correct
								if ($isPasswordCorrect) {;
									// Enregistrement des variables sessions
									$_SESSION['connexion'] = true;
									$_SESSION['id'] = $resultat['id'];
									$_SESSION['login'] = $resultat['login'];
									$_SESSION['group'] = $resultat['id_group'];
									$_SESSION['email'] = $resultat['email'];
									// Requête pour récupérer le nombre maximum d'avatar
									$reponse = $bdd->query('SELECT id FROM groupe  ORDER BY ID DESC LIMIT 0, 1');
									$nb_avatar = $reponse->fetch();
									// Requête pour récupérer l'url de l'avatar de l'utilisateur
									$reponse = $bdd->query("SELECT lien FROM avatar_compte WHERE id = '".rand(1,$nb_avatar['id'])."'");
									$avatar = $reponse->fetch();
									$_SESSION['avatar'] = $avatar['lien'];
									$_SESSION['signup_date'] = $resultat['signup_date'];
									// Requête pour enregistrer la date de connexion
									$req = $bdd->prepare('UPDATE users SET last_connect = :last_connect WHERE login = :login');
									$req->execute(array(
										'last_connect' => date("Y-m-d"),
										'login' => $_POST['login']
										));
										$_SESSION['last_connect']=$last_connect;
									$_SESSION['message']="";
									$form = false;
								}
								else {
									$form = true;
									$message = 'Mauvais identifiant ou mot de passe !';
								}
							}
						}
						//Génération du message d'erreur : champs vide
						else
						{
							$form = true;
							$message = 'Mauvais identifiant ou mot de passe !';
						}
						// Affichage du message d'information de validation du formulaire
						if(isset($message))
						{
							echo '<div class="message">'.$message.'</div>';
						}
						if($form)
						{
							echo "<div class='content'>";
								echo "<form action='connexion_verif.php' method='post'>";
									echo "<div class='center'>";
										echo "<label for='login'>Nom d'utilisateur</label><input type='text' name='login' value ='' /> <br />";
										echo "<label for='password'>Mot de passe<span class='small'></span></label><input type='password' name='password' value ='' /><br />";
									
										echo "<input type='submit' value='Envoyer' />";
									echo "</div>";
								echo "</form>";
							echo "</div>";	
						}
						else
						{
							header('Location: index.php');
							exit();	
						}
					?>
				</section>
			</div>
			<!-- Block bannière -->
			<div class ="banniere">
				
			</div>
		</div>
		
		<!-- Footer -->
		<?php include("footer.php");?>
	</body>
</html>
<!-- 
    Document  : Page d'accueil du PA
    Modify on : 08 oct. 2018
    Author    : Louis
	Group 	  : Hubert, Thibault, Guillaume, Louis, Aurélien
-->
<?php
	session_start();
?>
<!DOCTYPE html>
<html>
	<head>
		<title>Recherche Membre</title>
		<meta charset="UTF-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel="stylesheet" href="style.css" />
	</head>
	<body>
		<?php include("bandeau_avatar.php")?>

		<!-- Menu compte -->
		<?php include("menu_compte.php");?>

		<!-- The flexible grid (content) -->
		<div id="conteneur_central">
			<?php include("menu_navigation.php");?>
			<div class="main">
				<section>
					<h1>Membres du site</h1>
					<?php
						include("bdd_connexion.php");
						echo "<form action='membres_recherche.php' method='post'>";
							echo "<label for='membre_recherche'>Rechercher un membre </label><br />";
							echo "<input type='text' name ='membre_recherche' id='membre_recherche' /><br />";
							// Requête pour récupérer tous les groupes
							$reponse = $bdd->query('SELECT id,groupe FROM groupe');									
							// Affichage des groupes (les données sont protégées grâce à htmlspecialchars)
							while($donnees = $reponse->fetch())
							{	
								echo "<input type='radio' name='groupe_recherche' value='".htmlspecialchars($donnees['id'])."' id='".htmlspecialchars($donnees['groupe'])."' /><label for='".htmlspecialchars($donnees['groupe'])."'>".htmlspecialchars($donnees['groupe'])."</label><br />";
							}
							echo "<input type='submit' value='Envoyer' />";
						echo "</form>";
						
						// Requête pour récupérer tous les membres du site
						$reponse = $bdd->query('SELECT id, login, id_group, last_connect FROM users');

						// Affichage de tous les membres du site (les données sont protégées grâce à htmlspecialchars)
						while($donnees_membres = $reponse->fetch())
						{
							$req = $bdd->query("SELECT groupe FROM groupe WHERE id = '".htmlspecialchars($donnees_membres['id_group'])."'"); 
							$nom_group = $req->fetch();
							echo "<p>".htmlspecialchars($donnees_membres['id'])." - <strong>".htmlspecialchars($donnees_membres['login'])."</strong> : ".$nom_group['groupe']." <strong>Dernière connexion : </strong>".htmlspecialchars($donnees_membres['last_connect'])."</p>";
						}
						$reponse->closeCursor();
						
					?>
			
				</section>
			</div>
			<!-- Block bannière -->
			<div class ="banniere">
				
			</div>
		</div>
		
		<!-- Footer -->
		<?php include("footer.php");?>
	</body>
</html>
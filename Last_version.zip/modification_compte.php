﻿<!-- 
    Document  : Page d'accueil du PA
    Modify on : 08 oct. 2018
    Author    : Louis
	Group 	  : Hubert, Thibault, Guillaume, Louis, Aurélien
-->
<?php
	session_start();
?>
<!DOCTYPE html>
<html>
	<head>
		<title>Inscription</title>
		<meta charset="UTF-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel="stylesheet" href="style.css" />
	</head>
	<body>
		<?php include("bandeau_avatar.php")?>

		
		<!-- Menu compte -->
		<?php include("menu_compte.php");?>

		<!-- The flexible grid (content) -->
		<div id="conteneur_central">
			<?php include("menu_navigation.php");?>
			<div class="main">
				<section>
					<div class='content'>
						<?php
							//Vérification d'envoie de formulaire avec au moins un paramètre remplie
							if($_POST['login'] != "" || $_POST['password'] != "" && $_POST['passverif'] != "" || $_POST['email'] != "")
							{
								// connexion a la bdd
								include("bdd_connexion.php");
								$modif_champs = false;
								$modif_login = false;
								$modif_password = false;
								$modif_email = false;
								//Modification du login
								if($_POST['login'] != "")
								{
									$login = $_POST['login'];	
									// Vérification que le login n'est pas déjà utilisé
									$reponse = $bdd->query('SELECT login FROM users  WHERE login="'.$_POST['login'].'"');
									$loginverif = $reponse->fetch();
									if ($_POST['login'] != $loginverif['login'])
									{
										//Requête pour modifier le login
										$req = $bdd->prepare('UPDATE users SET login = :new_login WHERE login = :old_login');
										$req->execute(array(
											'new_login' => $login,
											'old_login' => $_SESSION['login']
											));
											$_SESSION['login'] = $login;
									}
									//Génération du message d'erreur : pseudo existant
									else
									{
										$modif_login = true;
										echo 'Nom d\'utilisateur existant.';
									}
								}
								//Modification du mot de passe
								if($_POST['password'] != "" && $_POST['passverif'] != "")
								{
									//Vérification des mots de passe identiques
									if($_POST['password']==$_POST['passverif'])
									{
										//Vérification du mot de passe a 6 caracteres ou plus
										if(strlen($_POST['password'])>=6)
										{
											$password = password_hash($_POST['password'], PASSWORD_DEFAULT);
											//Requête pour modifier le mot de passe
											$req = $bdd->prepare('UPDATE users SET password = :password WHERE login = :login');
											$req->execute(array(
												'password' => $password,
												'login' => $_SESSION['login']
												));
												$_SESSION['password'] = $password;
										}
										// Génération du message d'erreur : Mot de passe trop court
										else
										{
											$modif_password = true;
											echo 'Le mot de passe saisie est inférieur à 6 caractères.';
										}
									}
									// Génération du message d'erreur : Erreur correspondance de mot de passe
									else
									{
										$modif_password = true;
										echo 'Les mots de passe saisient ne sont pas identiques.';
									}
								}
								//Modification de l'email
								if($_POST['email'] != "")
								{
									//Vérification d'un email valide
									if(preg_match('#^(([a-z0-9!\#$%&\\\'*+/=?^_`{|}~-]+\.?)*[a-z0-9!\#$%&\\\'*+/=?^_`{|}~-]+)@(([a-z0-9-_]+\.?)*[a-z0-9-_]+)\.[a-z]{2,}$#i',$_POST['email']))
									{				
										$email = $_POST['email'];
										// Vérification que l'email n'est pas déjà utilisé
										$reponse = $bdd->query('SELECT email FROM users  WHERE email="'.$_POST['email'].'"');
										$emailverif = $reponse->fetch();
										if ($_POST['email'] != $emailverif['email'])
										{
											// Requête pour modifier l'email
											$req = $bdd->prepare('UPDATE users SET email = :email WHERE login = :login');
											$req->execute(array(
												'email' => $email,
												'login' => $_SESSION['login']
												));
												$_SESSION['email']=$email;
										}
										//Génération du message d'erreur : email existant
										else
										{
											$modif_email = true;
											echo 'Email déjà utilisé.';
										}
									}
									// Génération du message d'erreur : Email invalide
									else
									{
										$modif_email = true;
										echo 'L\'email saisie est invalide.';
									}
								}
							}
							//Génération du message d'erreur : champs vide
							else
							{
								$modif_champs = true;
								echo'Au moins une information doit être modifiée.';
							}
							//Vérification de la demande de modification d'au moins une informations
							if($modif_champs || $modif_login || $modif_password || $modif_email)
							{
								echo "<div class='content'>";
									echo "<h1>Modification des informations du compte</h1>";
									echo "<form action='modification_compte.php' method='post'>";
										echo "<div class='center'>";
											echo "<label for='login'>Nouveau nom d'utilisateur</label><input type='text' name='login' value ='' /> <br />";
											echo "<label for='password'>Nouveau mot de passe<span class='small'>(6 caractères min.)</span></label><input type='password' name='password' value ='' /><br />";
											echo "<label for='passverif'>Mot de passe<span class='small'>(vérification)</span></label><input type='password' name='passverif' value ='' /><br />";
											echo "<label for='email'>Nouvel email</label><input type='text' name='email' value =''/><br />";
											
											echo "<input type='submit' value='Envoyer' />";
										echo "</div>";
									echo "</form>";	
								echo "</div>";
							}
							else
							{
								header('Location: compte.php');
								exit();
							}
						?>
					</div>
				</section>
			</div>
			<!-- Block bannière -->
			<div class ="banniere">
				
			</div>
		</div>
		
		<!-- Footer -->
		<?php include("footer.php");?>
	</body>
</html>
﻿<!-- 
    Document  : Page d'accueil du PA
    Modify on : 08 oct. 2018
    Author    : Louis
	Group 	  : Hubert, Thibault, Guillaume, Louis, Aurélien
-->
<?php
	session_start();
?>
<!DOCTYPE html>
<html>
	<head>
		<title>Inscription</title>
		<meta charset="UTF-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel="stylesheet" href="style.css" />
	</head>
	<body>
		<?php include("bandeau_avatar.php")?>

		<!-- Menu compte -->
		<?php include("menu_compte.php");?>

		<!-- The flexible grid (content) -->
		<div id="conteneur_central">
			<?php include("menu_navigation.php");?>
			<div class="main">
				<section>
					<div class='content'>
						<?php
							// connexion a la bdd
							include("bdd_connexion.php");
							//Vérification d'envoie de formulaire
							if($_POST['login'] != "" && $_POST['password'] != "" && $_POST['passverif'] != "" && $_POST['email'] != "")
							{
								if(preg_match('#^(([A-Za-z0-9!\#$%&\\\'*+/=?^_`{|}~-]+\.?)*[A-Za-z0-9!\#$%&\\\'*+/=?^_`{|}~-]+)#', $_POST['login']))
								{
									//Vérification des mots de passe identiques
									if($_POST['password']==$_POST['passverif'])
									{
										//Vérification du mot de passe a 6 caracteres ou plus
										if(strlen($_POST['password'])>=6)
										{
											//Vérification d'un email valide
											if(preg_match('#^(([a-z0-9!\#$%&\\\'*+/=?^_`{|}~-]+\.?)*[a-z0-9!\#$%&\\\'*+/=?^_`{|}~-]+)@(([a-z0-9-_]+\.?)*[a-z0-9-_]+)\.[a-z]{2,}$#i',$_POST['email']))
											{				
												$login = $_POST['login'];
												$password = password_hash($_POST['password'], PASSWORD_DEFAULT);
												$email = $_POST['email'];
												$signup_date = date("Y-m-d");
												// Vérification que le login n'est pas déjà utilisé
												$reponse = $bdd->query('SELECT login FROM users  WHERE login="'.$_POST['login'].'"');
												$loginverif = $reponse->fetch();
												if ($_POST['login'] != $loginverif['login'])
												{
													// Vérification que l'email n'est pas déjà utilisé
													$reponse = $bdd->query('SELECT email FROM users  WHERE email="'.$_POST['email'].'"');
													$emailverif = $reponse->fetch();
													if ($_POST['email'] != $emailverif['email'])
													{
														// Requête pour insérer l'utilisateur si toutes les conditions sont validées
														$reponse = $bdd->prepare('INSERT INTO users(login, password, email, signup_date) VALUES(:login, :password, :email, :signup_date)');
														$reponse->execute(array(
															'login' => $login,
															'password' => $password,
															'email' => $email,
															'signup_date' => $signup_date,
														));
														$message = 'Votre compte à bien été crée. <br /> Vous pouvez maintenant vous connecter.';
														$form = false;
													}
													//Génération du message d'erreur : email existant
													else
													{
														$form = true;
														$message = 'Email déjà utilisé.';
													}
												}
												//Génération du message d'erreur : pseudo existant
												else
												{
													$form = true;
													$message = 'Nom d\'utilisateur existant.';
												}
											}
											// Génération du message d'erreur : Email invalide
											else
											{
												$form = true;
												$message = 'L\'email saisie est invalide.';
											}
										}
										// Génération du message d'erreur : Mot de passe trop court
										else
										{
											$form = true;
											$message = 'Le mot de passe saisie est inférieur à 6 caractères.';
										}
									}
									// Génération du message d'erreur : Erreur correspondance de mot de passe
									else
									{
										$form = true;
										$message = 'Les mots de passe saisient ne sont pas identiques.';
									}
								}
								// Génération du message d'erreur : Login invalide
								else
								{
									$form = true;
									$message = 'Le nom d\'utilisateur saisie est invalide.';
								}
							}
							//Génération du message d'erreur : champs vide
							else
							{
								$form = true;
								$message = 'Tous les champs doivent être remplis.';
							}
							// Affichage du message d'information de validation du formulaire
							if(isset($message))
							{
								echo '<div class="message">'.$message.'</div>';
							}
							if($form)
							{
								echo "<div class='content'>";
									echo "<h1>Inscription</h1>";
									echo "<form action='inscription_verif.php' method='post'>";
										echo "<div class='center'>";
											echo "<label for='login'>Nom d'utilisateur</label><input type='text' name='login' /> <br />";
											echo "<label for='password'>Mot de passe<span class='small'>(6 caractères min.)</span></label><input type='password' name='password' /><br />";
											echo "<label for='passverif'>Mot de passe<span class='small'>(vérification)</span></label><input type='password' name='passverif' /><br />";
											echo "<label for='email'>Email</label><input type='text' name='email' /><br />";
											
											echo "<input type='submit' value='Envoyer' />";
										echo "</div>";
									echo "</form>";
								echo "</div>";
							}
						?>
					</div>
				</section>
			</div>
			<!-- Block bannière -->
			<div class ="banniere">
				
			</div>
		</div>
		
		<!-- Footer -->
		<?php include("footer.php");?>
	</body>
</html>
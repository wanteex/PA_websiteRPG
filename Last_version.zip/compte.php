﻿<!-- 
    Document  : Page d'accueil du PA
    Modify on : 08 oct. 2018
    Author    : Louis
	Group 	  : Hubert, Thibault, Guillaume, Louis, Aurélien
-->
<?php
	session_start();
?>
<!DOCTYPE html>
<html>
	<head>
		<title>Mon compte</title>
		<meta charset="UTF-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel="stylesheet" href="style.css" />
	</head>
	<body>
		<?php include("bandeau_avatar.php")?>

		<!-- Menu compte -->
		<?php include("menu_compte.php");?>

		<!-- The flexible grid (content) -->
		<div id="conteneur_central">
			<?php include("menu_navigation.php");?>
			<div class="main">
				<section>
					<?php
						echo "<div class='conteneur_contact'>";
							// Connexion a la bdd
							include("bdd_connexion.php");
							// Requête pour récupérer le nom de groupe de l'utilisateur
							$reponse = $bdd->query('SELECT groupe FROM groupe WHERE id = "'.$_SESSION['group'].'"');
							$donnees = $reponse->fetch();
							echo "<h1>Information de compte</h1><br />";
							// Affichage de l'avatar de l'utilisateur
							echo "<img src='".$_SESSION['avatar']."' alt='Avatar' /><br />";
							// Affichage du login de l'utilisateur
							echo "<strong>Nom d'utilisateur : </strong>".htmlspecialchars($_SESSION['login'])."<br />";
							// Affichage du groupe de l'utilisateur
							echo "<strong>Statut : </strong>".htmlspecialchars($donnees['groupe'])."<br />";
							// Affichage de l'email de l'utilisateur
							echo "<strong>Email : </strong>".htmlspecialchars($_SESSION['email'])."<br />";
							// Affichage de la date d'inscription de l'utilisateur
							echo "<strong>Inscrit le : </strong>".htmlspecialchars($_SESSION['signup_date'])."<br />";
						echo "</div>";
						echo "<div class='content'>";
							echo "<h1>Modification des informations du compte</h1>";
							echo "<form action='modification_compte.php' method='post'>";
								echo "<div class='center'>";
									echo "<label for='login'>Nouveau nom d'utilisateur</label><input type='text' name='login' value ='' /> <br />";
									echo "<label for='password'>Nouveau mot de passe<span class='small'>(6 caractères min.)</span></label><input type='password' name='password' value ='' /><br />";
									echo "<label for='passverif'>Mot de passe<span class='small'>(vérification)</span></label><input type='password' name='passverif' value ='' /><br />";
									echo "<label for='email'>Nouvel email</label><input type='text' name='email' value =''/><br />";
									
									echo "<input type='submit' value='Envoyer' />";
								echo "</div>";
							echo "</form>";
						echo "</div>";
					?>
 
				</section>
			</div>
			<!-- Block bannière -->
			<div class ="banniere">
				
			</div>
		</div>
		
		<!-- Footer -->
		<?php include("footer.php");?>
	</body>
</html>
﻿<!-- 
    Document  : Page d'accueil du PA
    Modify on : 08 oct. 2018
    Author    : Louis
	Group 	  : Hubert, Thibault, Guillaume, Louis, Aurélien
-->
<?php
	session_start();
?>
<!DOCTYPE html>
<html>
	<head>
		<title>Panneau d'administration</title>
		<meta charset="UTF-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel="stylesheet" href="style.css" />
	</head>
	<body>
		<?php include("bandeau_avatar.php")?>

		<!-- Menu compte -->
		<?php include("menu_compte.php");?>

		<!-- The flexible grid (content) -->
		<div id="conteneur_central">
			<?php include("menu_navigation.php");?>
			<div class="main">
				<section>
					<?php
						if(	isset($_POST['modif_user']) && (isset($_POST['modif_user_groupe']) || isset($_POST['modif_user_login']) || isset($_POST['modif_user_password']) || isset($_POST['modif_user_email'])))
						{
							$_SESSION['message']="";
							// Connexion à la base de donnée
							include("bdd_connexion.php");
							// Test pour modifier les droits de l'utilisateur
							if($_POST['modif_user_groupe']!="")
							{
								// Requête pour modifier les droits de l'utilisateur
								$req = $bdd->prepare('UPDATE users SET id_group = :id_group WHERE login = :login');
								$req->execute(array(
									'id_group' => $_POST['modif_user_groupe'],
									'login' => $_POST['modif_user']
									));	
							}
							// Test pour modifier le login de l'utilisateur
							if($_POST['modif_user_login']!="")
							{
								$new_login = $_POST['modif_user_login'];
								$old_login = $_POST['modif_user'];
								// Vérification que le login n'est pas déjà utilisé
								$reponse = $bdd->query('SELECT login FROM users  WHERE login="'.$new_login.'"');
								$loginverif = $reponse->fetch();
								if ($new_login != $loginverif['login'])
								{
									//Requête pour modifier le login
									$req = $bdd->prepare('UPDATE users SET login = :new_login WHERE login = :old_login');
									$req->execute(array(
										'new_login' => $new_login,
										'old_login' => $old_login
										));
								}
								//Génération du message d'erreur : pseudo existant
								else
								{
									$_SESSION['message'] = 'Nom d\'utilisateur existant.';
								}
							}
							// Test pour modifier le mot de passe de l'utilisateur
							if($_POST['modif_user_password'] != "")
							{
								//Vérification du mot de passe a 6 caracteres ou plus
								if(strlen($_POST['modif_user_password'])>=6)
								{
									// Hashage du mot de passe
									$password = password_hash($_POST['modif_user_password'], PASSWORD_DEFAULT);
									//Requête pour modifier le mot de passe
									$req = $bdd->prepare('UPDATE users SET password = :password WHERE login = :login');
									$req->execute(array(
										'password' => $password,
										'login' => $_POST['modif_user']
										));
								}
								// Génération du message d'erreur : Mot de passe trop court
								else
								{
									$_SESSION['message'] = 'Le mot de passe saisie est inférieur à 6 caractères.';
								}
							}
							// Test pour modifier l'email de l'utilisateur
							if($_POST['modif_user_email'] != "")
							{
								//Vérification d'un email valide
								if(preg_match('#^(([a-z0-9!\#$%&\\\'*+/=?^_`{|}~-]+\.?)*[a-z0-9!\#$%&\\\'*+/=?^_`{|}~-]+)@(([a-z0-9-_]+\.?)*[a-z0-9-_]+)\.[a-z]{2,}$#i',$_POST['modif_user_email']))
								{				
									$email = $_POST['modif_user_email'];
									// Vérification que l'email n'est pas déjà utilisé
									$reponse = $bdd->query('SELECT email FROM users  WHERE email="'.$email.'"');
									$emailverif = $reponse->fetch();
									if ($email != $emailverif['email'])
									{
										// Requête pour modifier l'email
										$req = $bdd->prepare('UPDATE users SET email = :email WHERE login = :login');
										$req->execute(array(
											'email' => $email,
											'login' => $_POST['modif_user']
											));
									}
									//Génération du message d'erreur : email existant
									else
									{
										$_SESSION['message'] = 'Email déjà utilisé.';
									}
								}
								// Génération du message d'erreur : Email invalide
								else
								{
									$_SESSION['message'] = 'L\'email saisie est invalide.';
								}
							}
							header('Location: admin.php');
							exit();
						}
						else
						{
							$_SESSION['message'] = "Au moins un champ doit être renseigné.";
						}
					?>
				</section>
			</div>
			<!-- Block bannière -->
			<div class ="banniere">
				
			</div>
		</div>
		
		<!-- Footer -->
		<?php include("footer.php");?>
	</body>
</html>
﻿<!-- 
    Document  : Page d'accueil du PA
    Modify on : 08 oct. 2018
    Author    : Louis
	Group 	  : Hubert, Thibault, Guillaume, Louis, Aurélien
-->
<?php
	session_start();
?>
<!DOCTYPE html>
<html>
	<head>
		<title>Inscription</title>
		<meta charset="UTF-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel="stylesheet" href="style.css" />
	</head>
	<body>
		<?php include("bandeau_avatar.php")?>

		
		<!-- Menu compte -->
		<?php include("menu_compte.php");?>

		<!-- The flexible grid (content) -->
		<div id="conteneur_central">
			<?php include("menu_navigation.php");?>
			<div class="main">
				<section>
					<h1>Inscription</h1>
					<?php
						echo "<div class='content'>";
							echo "<form action='inscription_verif.php' method='post'>";
								echo "<p>Veuillez remplir ce formulaire pour vous inscrire:</p>";
								echo "<div class='center'>";	
									echo "<label for='login'>Nom d'utilisateur</label><input type='text' name='login' value ='' /> <br />";
									echo "<label for='password'>Mot de passe<span class='small'>(6 caractères min.)</span></label><input type='password' name='password' value ='' /><br />";
									echo "<label for='passverif'>Mot de passe<span class='small'>(vérification)</span></label><input type='password' name='passverif' value ='' /><br />";
									echo "<label for='email'>Email</label><input type='text' name='email' value =''/><br />";
									
									echo "<input type='submit' value='Envoyer' />";
								echo "</div>";
							echo "</form>";
						echo "</div>";
					?>
				</section>
			</div>
			<!-- Block bannière -->
			<div class ="banniere">
				
			</div>
		</div>
		
		<!-- Footer -->
		<?php include("footer.php");?>
	</body>
</html>
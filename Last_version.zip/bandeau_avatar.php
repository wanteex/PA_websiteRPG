<?php
	echo "<div id='logo_header'>";
	// Connexion à la base de donnée
	include("bdd_connexion.php");
	// Requête pour récupérer le nombre maximum d'avatar
	$reponse = $bdd->query('SELECT id FROM avatar_compte  ORDER BY ID DESC LIMIT 0, 1');
	$nb_avatar = $reponse->fetch();
	// Boucle pour afficher 9 avatars dans le bandeau
	$i = 1;
	while ($i < 10):
		// Requête pour récupérer l'url de l'avatar de l'utilisateur
		$reponse = $bdd->query("SELECT lien FROM avatar_compte WHERE id = '".rand(1,$nb_avatar['id'])."'");
		$avatar = $reponse->fetch();
		echo "<img class='avatar_bandeau'	src='".$avatar['lien']."' alt='Avatar_'".$i." />";
		$i++;
	endwhile;
	echo "</div>";
?>
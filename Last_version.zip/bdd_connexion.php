<?php
// connexion à la base de donnée
try
{
	$bdd = new PDO('mysql:host=localhost;dbname=id8493721_clubjdr;charset=utf8', 'id8493721_admin', 'jdrEsaip2019');
}
catch(Exception $e)
{
		die('Erreur : '.$e->getMessage());
}
?>
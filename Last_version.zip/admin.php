﻿<!-- 
    Document  : Page d'accueil du PA
    Modify on : 08 oct. 2018
    Author    : Louis
	Group 	  : Hubert, Thibault, Guillaume, Louis, Aurélien
-->
<?php
	session_start();
?>
<!DOCTYPE html>
<html>
	<head>
		<title>Panneau d'administration</title>
		<meta charset="UTF-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel="stylesheet" href="style.css" />
	</head>
	<body>
		<?php include("bandeau_avatar.php")?>
		<!-- Header -->
		<div class="header">
		  <h1>Jeux de Rôles</h1>
		</div>
		
		<!-- Menu compte -->
		<?php include("menu_compte.php");?>

		<!-- The flexible grid (content) -->
		<div id="conteneur_central">
			<?php include("menu_navigation.php");?>
			<div class="main">
				<section>
					<h1>Panneau d'administration</h1>
					<?php
						echo $_SESSION['message'];
						// Connexion a la bdd
						include("bdd_connexion.php");

						
						echo "<div class='content'>";
							echo "<form action='admin_modif.php' method='post'>";
								echo "<div class='center'>";
									//Zone de saisie du login de l'utilisateur à modifié
									echo "<label for='modif_user'>Modification sur l'utilisateur </label><input type='text' name='modif_user' id = 'modif_user' /> <br />";
									// Modification des droits
									echo "<h4>Modification des droits :</h4>";
									// Requête pour récupérer les groupes
									$reponse = $bdd->query('SELECT id,groupe FROM groupe');									
									// Affichage des groupes (les données sont protégées grâce à htmlspecialchars)
									while ($donnees = $reponse->fetch())
									{	
										echo "<input type='radio' name='modif_user_groupe' value='".htmlspecialchars($donnees['id'])."' id='".htmlspecialchars($donnees['groupe'])."' /><label for='".htmlspecialchars($donnees['groupe'])."'>".htmlspecialchars($donnees['groupe'])."</label><br />";
									}
									$reponse->closeCursor();
									// Modification du pseudo
									echo "<h4>Changement de pseudo</h4>";
									echo "<label for='modif_user_login'>Nouveau login </label><input type='text' name='modif_user_login' id = 'modif_user_login' /> <br />";
									
									// Modification du mot de passe
									echo "<h4>Changement de mot de passe</h4>";
									echo "<label for='modif_user_password'>Nouveau mot de passe </label><input type='text' name='modif_user_password' id = 'modif_user_password' /> <br />";
									
									// Modification de l'email
									echo "<h4>Changement d'email</h4>";
									echo "<label for='modif_user_email'>Nouvel email </label><input type='text' name='modif_user_email' id = 'modif_user_email' /> <br />";
									
									echo "<input type='submit' value='Envoyer' />";
									
									
									
								echo "</div>";
							echo "</form>";
						echo "</div>";
					?>
				</section>
			</div>
			<!-- Block bannière -->
			<div class ="banniere">
				
			</div>
		</div>
		
		<!-- Footer -->
		<?php include("footer.php");?>
	</body>
</html>
<!-- 
    Document  : Page d'accueil du PA
    Modify on : 08 oct. 2018
    Author    : Louis
	Group 	  : Hubert, Thibault, Guillaume, Louis, Aurélien
-->
<?php
	session_start();
?>
<!DOCTYPE html>
<html>
	<head>
		<title>FAQ</title>
		<meta charset="UTF-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel="stylesheet" href="style.css" />
	</head>
	<body>
		<?php include("bandeau_avatar.php")?>

		
		<!-- Menu compte -->
		<?php include("menu_compte.php");?>

		<!-- The flexible grid (content) -->
		<div id="conteneur_central">
			<?php include("menu_navigation.php");?>
			<div class="main">
				<section>
					<h1>FAQ</h1>
					<?php
						echo "<p>";
							if (isset($_SESSION['connexion']) && ($_SESSION['group'] == 4))
							{
								echo "<form action='faq_ajout.php' method='post'>";
									echo "<label for='faq_modif_id'>Modifier le message <span class='small'>(id du message)</span>:</label><br />";
									echo "<input type='text' name ='faq_modif_id' id='faq_modif_id' /><br />";

									echo "<label for='faq_question'>Question : </label><br />";
									echo "<textarea name='faq_question' id='faq_question' rows='2' cols='80'></textarea><br />";
									echo "<label for='faq_reponse'>Reponse : </label><br />";
									echo "<textarea name='faq_reponse' id='faq_reponse' rows='5' cols='80'></textarea><br />";

									echo "<input type='submit' value='Envoyer' />";
								echo "</form>";
							}
						echo "</p>";
					
				// Connexion à la base de données
				include("bdd_connexion.php");
				// Requête pour récupérer tous les messages
				$reponse = $bdd->query('SELECT id, question, reponse FROM faq');

				// Affichage des messages(les données sont protégées grâce à htmlspecialchars)
				while ($donnees = $reponse->fetch())
				{
					echo "<p><div class='block_faq'>";
					echo "<h4>".htmlspecialchars($donnees['id'])." - ".htmlspecialchars($donnees['question'])."</h4>";
					echo htmlspecialchars($donnees['id'])." - ".htmlspecialchars($donnees['reponse'])."<br /></div>";
				}
				$reponse->closeCursor();
			?>
				</section>
			</div>
			<!-- Block bannière -->
			<div class ="banniere">
				
			</div>
		</div>
		
		<!-- Footer -->
		<?php include("footer.php");?>
	</body>
</html>
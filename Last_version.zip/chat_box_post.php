<!-- 
    Document  : Page d'accueil du PA
    Modify on : 08 oct. 2018
    Author    : Louis
	Group 	  : Hubert, Thibault, Guillaume, Louis, Aurélien
-->
<?php
	session_start();
?>
<!DOCTYPE html>
<html>
	<head>
		<title>Chat Box</title>
		<meta charset="UTF-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel="stylesheet" href="style.css" />
	</head>
	<body>
		<?php include("bandeau_avatar.php")?>

		
		<!-- Menu compte -->
		<?php include("menu_compte.php");?>

		<!-- The flexible grid (content) -->
		<div id="conteneur_central">
			<?php include("menu_navigation.php");?>
			<div class="main">
				<section>
					<h1>Chat Box</h1>
					    <?php
							// Connexion à la base de données
							include("bdd_connexion.php");
							// Test pour envoyer un message
							if($_POST['chat_box_message']!="")
							{
								// Requête préparée pour insérer un message
								$req = $bdd->prepare('INSERT INTO chat_box (login, message, message_heure) VALUES(?, ?, ?)');
								$req->execute(array($_SESSION['login'], $_POST['chat_box_message'], date("H:i:s")));
								$_SESSION['message']="";
							}
							else
							{
								$_SESSION['message'] = "Vous êtes stupide...";
							}
							echo $_POST['chat_box_moderation_id']."<br />";
							// Test pour supprimer un message
							if($_POST['chat_box_moderation_id']!="")
							{
								//Requête pour supprimer le message
								$req = "DELETE FROM chat_box WHERE id='".$_POST['chat_box_moderation_id']."'";
								$bdd->exec($req);
								$_SESSION['message']="";
							}
							// Redirection du visiteur vers la page du minichat
							header('Location: chat_box.php');
							exit();
						?>
				</section>
			</div>
			<!-- Block bannière -->
			<div class ="banniere">
				
			</div>
		</div>
		
		<!-- Footer -->
		<?php include("footer.php");?>
	</body>
</html>
<div class="menu_page">
				<nav>
					<ul>
						<li><a href="index.php">Accueil</a></li>
						<?php						
							if (isset($_SESSION['connexion']))
							{
								echo "<li><a href='compte.php'>Mon Compte</a></li>";
							}
						?>
						<li><a href="news.php">News</a></li>
						<?php						
							if (isset($_SESSION['connexion']) && $_SESSION['group'] == 4)
							{
								echo "<li><a href='nouvelle_news.php'>Nouvelle news</a></li>";
							}
						?>
						<li><a href="forum.php">Forum</a></li>
						<li><a href="faq.php">FAQ</a></li>
						<li><a href="contact.php">Contact</a></li>
					</ul>
					<ul>
                        <li><a href="stormbringer.php">Stormbringer</a></li>
                        <li><a href='see_nationality.php'>Nationalités</a></li>
                        <li><a href='see_class.php'>Classes sociales</a></li>
                        <li><a href='achat_storm.php'>Tables des achats</a></li>
                        <li><a href='see_cult.php'>Cultes</a></li>
						<?php						
							if (isset($_SESSION['id']) && isset($_SESSION['login']))
							{
								echo "<li><a href='character_creation.php'>Créer un personnage</a></li>
								<li><a href='see_character.php'>Voir ses personnages</a></li>
				                <li><a href='character_registration.php'>Enregistrer un personnages</a></li>";
							}
						?>						
					</ul>
				</nav>
			</div>
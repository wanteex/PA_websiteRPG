﻿<!-- 
    Document  : Page d'accueil du PA
    Modify on : 08 oct. 2018
    Author    : Louis
	Group 	  : Hubert, Thibault, Guillaume, Louis, Aurélien
-->
<?php
	session_start();
?>
<!DOCTYPE html>
<html>
	<head>
		<title>Accueil</title>
		<meta charset="UTF-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel="stylesheet" href="style.css" />
	</head>
	<body>
		<?php include("bandeau_avatar.php")?>

		
		<!-- Menu compte -->
		<?php include("menu_compte.php");?>

		<!-- The flexible grid (content) -->
		<div id="conteneur_central">
			<?php include("menu_navigation.php");?>
			<div class="main">
				<section>
					<h1>Dernière News</h1>
					<?php include("bdd_connexion.php");
						$reponse = $bdd->query('SELECT id, title, content, lien_source, creation_date, modification_date FROM news ORDER BY modification_date DESC LIMIT 0,3');
						// Affichage des 3 dernière news (les données sont protégées grâce à htmlspecialchars)
						while ($donnees = $reponse->fetch())
						{
							echo "<div class='block_news'>";
							echo "<h3>".htmlspecialchars($donnees['title'])."</h3>";
							echo "<p>".htmlspecialchars($donnees['content'])."</p>";
							if($donnees['lien_source'] != "")
							{
								echo "<strong>Date de création : </strong>".htmlspecialchars($donnees['creation_date'])." /<strong> Dernière modification : </strong>".htmlspecialchars($donnees['modification_date'])." /<strong> ID : </strong>".htmlspecialchars($donnees['id'])." / <a href='".htmlspecialchars($donnees['lien_source'])."'>Source</a><br />";
							}
							else
							{
								echo "<strong>Date de création : </strong>".htmlspecialchars($donnees['creation_date'])." /<strong> Dernière modification : </strong>".htmlspecialchars($donnees['modification_date'])." /<strong> ID : </strong>".htmlspecialchars($donnees['id'])."<br />";
							}
							echo "</div>";
						}
						$reponse->closeCursor();
					?>
				</section>
			</div>
			<!-- Block bannière -->
			<div class ="banniere">
				
			</div>
		</div>
		
		<!-- Footer -->
		<?php include("footer.php");?>
	</body>
</html>
    Modify on : 08 oct. 2018
    Author    : Guillaume
	Group 	  : Hubert, Thibault, Guillaume, Louis, Aurélien
-->
<?php
	session_start();
?>
<!DOCTYPE html>
<html>
	<head>
		<title>Achat Stormbringer</title>
		<meta charset="UTF-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel="stylesheet" href="style.css" />
	</head>
	<body>
		<?php include("bandeau_avatar.php")?>

		
		<!-- Menu compte -->
		<?php include("menu_compte.php");?>

		<!-- The flexible grid (content) -->
		<div id="conteneur_central">
			<?php include("menu_navigation.php");?>
    <div class="main">
    <h1>Tableaux des achats possibles hors games</h1>
<?php 
    $reponse1 = $bdd->query('SELECT * FROM achat ');
    //$donnees2 = $reponse1 -> fetch();
    $bob = "Biens de consommation";
    echo "
                <h2>".$bob."</h2>
                <table>
                    <tr>
                        <td>Nom</td>
                        <td>Prix(GB)</td>
                    </tr>";
        
            $reponse = $bdd->query('SELECT * FROM achat WHERE categorie ="'.$bob.'"');
            while ($donnees = $reponse->fetch()){
            echo "<tr>
                    <td>".$donnees['name']."</td>
                    <td>".$donnees['prix(GB)']."</td>
                </tr>";
            }
        echo "</table>";
    
    
    while($donnees1 = $reponse1 -> fetch()){
        
        if($bob != $donnees1['categorie']){
            echo "
                <h2>".$donnees1['categorie']."</h2>
                <table>
                    <tr>
                        <td>Nom</td>
                        <td>Prix(GB)</td>
                    </tr>";
        
            $reponse = $bdd->query('SELECT * FROM achat WHERE categorie ="'.$donnees1['categorie'].'"');
            while ($donnees = $reponse->fetch()){
            echo "<tr>
                    <td>".$donnees['name']."</td>
                    <td>".$donnees['prix(GB)']."</td>
                </tr>";
            }
            echo"</table>";
            
        }
        $bob = $donnees1['categorie'];

    }
    
?>
    
    <h2>Armement</h2>
    <table>
        <tr>
            <td>Nom</td>
            <td>FOR minimum</td>
            <td>DEX minimum</td>
            <td>Dégats</td>
            <td>Prix(GB)</td>
            <td>Type</td>
            <td>Distance</td>     
        </tr>
        
<?php
        
    $reponse = $bdd->query('SELECT * FROM weapon ');
    while ($donnees = $reponse->fetch()){
        echo "<tr>
                <td>".$donnees['name']."</td>
                <td>".$donnees['FORC']."</td>
                <td>".$donnees['DEX']."</td>
                <td>".$donnees['damage']."</td>
                <td>".$donnees['price']."</td>
                <td>".$donnees['type']."</td>
                <td>".$donnees['distance']."</td>
            </tr>";
    }
?>
    </table>

</div>
		
		
<div class ="banniere">
				
			</div>
		</div>
		
		<!-- Footer -->
		<div class="footer">
		  <a href="mention_legale.html" target="_blank">Information Mention Légale</a>
		</div>
	</body>
</html>
<!-- 
    Document  : Page d'accueil du PA
    Modify on : 08 oct. 2018
    Author    : Louis
	Group 	  : Hubert, Thibault, Guillaume, Louis, Aurélien
-->
<?php
	session_start();
?>
<!DOCTYPE html>
<html>
	<head>
		<title>Contact</title>
		<meta charset="UTF-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel="stylesheet" href="style.css" />
	</head>
	<body>
		<?php include("bandeau_avatar.php")?>

		
		<!-- Menu compte -->
		<?php include("menu_compte.php");?>

		<!-- The flexible grid (content) -->
		<div id="conteneur_central">
			<?php include("menu_navigation.php");
				echo "<div class='main'>";
					echo "<section>";
						echo "<h1>Contact</h1>";
						include("bdd_connexion.php");
						// Requête pour récupérer les admins & maîtres du jeu
						$reponse = $bdd->query("SELECT login, id_group, email FROM users WHERE id_group = '2' OR id_group = '4'");	
						// Affichage de tous les membres du groupe
						while ($donnees_membres = $reponse->fetch())
						{
							$req = $bdd->query("SELECT groupe FROM groupe WHERE id = '".htmlspecialchars($donnees_membres['id_group'])."'"); 
							$nom_group = $req->fetch();
								echo "<div class='contact'>";
									echo "<p>";
										echo "<strong>Pseudo : </strong>".htmlspecialchars($donnees_membres['login'])."<br />";
										echo "<strong>Statut : </strong>".htmlspecialchars($nom_group['groupe'])."<br />";
										echo "<strong>Email : </strong>".htmlspecialchars($donnees_membres['email'])."<br />";
									echo "</p>";
								echo "</div><br />";
						}
						$reponse->closeCursor();
					echo "</section>";
				echo "</div>";
			?>
			<!-- Block bannière -->
			<div class ="banniere">
				
			</div>
		</div>
		
		<!-- Footer -->
		<?php include("footer.php");?>
	</body>
</html>
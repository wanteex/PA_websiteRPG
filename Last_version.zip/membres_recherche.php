<!-- 
    Document  : Page d'accueil du PA
    Modify on : 08 oct. 2018
    Author    : Louis
	Group 	  : Hubert, Thibault, Guillaume, Louis, Aurélien
-->
<?php
	session_start();
?>
<!DOCTYPE html>
<html>
	<head>
		<title>Résultat recherche</title>
		<meta charset="UTF-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel="stylesheet" href="style.css" />
	</head>
	<body>
		<?php include("bandeau_avatar.php")?>

		
		<!-- Menu compte -->
		<?php include("menu_compte.php");?>

		<!-- The flexible grid (content) -->
		<div id="conteneur_central">
			<?php include("menu_navigation.php");?>
			<div class="main">
				<section>
					<h1>Membres du site</h1>
					<?php
						include("bdd_connexion.php");
						
						// Test pour savoir si le champ membre_recherche est renseigné
						if(isset($_POST['membre_recherche']))
						{
							// Requête pour récupérer le membre recherché
							$reponse = $bdd->query("SELECT id, login, id_group, last_connect FROM users WHERE login = '".$_POST['membre_recherche']."'");

							// Affichage de tous les membres du site (les données sont protégées grâce à htmlspecialchars)
							while ($donnees_membres = $reponse->fetch())
							{
								$req = $bdd->query("SELECT groupe FROM groupe WHERE id = '".htmlspecialchars($donnees_membres['id_group'])."'"); 
								$nom_group = $req->fetch();
								echo "<p>".htmlspecialchars($donnees_membres['id'])." - <strong>".htmlspecialchars($donnees_membres['login'])."</strong> : ".$nom_group['groupe']." ".htmlspecialchars($donnees_membres['last_connect'])."</p>";
							}
							$reponse->closeCursor();
						}
						// Test pour savoir si la recherche par groupe est activée
						if(isset($_POST['groupe_recherche']))
						{
							// Requête pour récupérer groupe de membre recherché
							$reponse = $bdd->query("SELECT id, login, id_group,last_connect FROM users WHERE id_group = '".$_POST['groupe_recherche']."'");	
							// Affichage de tous les membres du groupe
							while ($donnees_membres = $reponse->fetch())
							{
								$req = $bdd->query("SELECT groupe FROM groupe WHERE id = '".htmlspecialchars($donnees_membres['id_group'])."'"); 
								$nom_group = $req->fetch();
								echo "<p>".htmlspecialchars($donnees_membres['id'])." - <strong>".htmlspecialchars($donnees_membres['login'])."</strong> : ".$nom_group['groupe']." Dernière connexion ".htmlspecialchars($donnees_membres['last_connect'])."</p>";
							}
							$reponse->closeCursor();							
						}
					?>
			
				</section>
			</div>
			<!-- Block bannière -->
			<div class ="banniere">
				
			</div>
		</div>
		
		<!-- Footer -->
		<?php include("footer.php");?>
	</body>
</html>